# 使用说明

代码需要在 Tensorflow 框架下运行

运行代码时请确保测试文件 `data\test.csv` 存在

识别结果文件路径 `result.csv`
